// package DN3.TaskManagementSystem;

class Node {
    Task task;
    Node next;

    public Node(Task task) {
        this.task = task;
    }
}