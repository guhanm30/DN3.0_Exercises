package com.library.repository;
import org.springframework.stereotype.Repository;

@Repository

public class BookRepository
 {
    // Repository logic methods
    public void performRepositoryAction() 
    {

        // Logic for repository actions
        System.out.println("Repository action performed");
    }
}